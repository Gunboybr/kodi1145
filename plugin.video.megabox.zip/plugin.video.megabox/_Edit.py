import xbmcaddon

MainBase = 'http://pastebin.com/raw/pLJTJe3H'
addon = xbmcaddon.Addon('plugin.video.megabox')